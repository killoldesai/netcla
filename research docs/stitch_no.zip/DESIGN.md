---
name: Engineered Momentum
colors:
  surface: '#121411'
  surface-dim: '#121411'
  surface-bright: '#383a36'
  surface-container-lowest: '#0d0f0c'
  surface-container-low: '#1a1c19'
  surface-container: '#1e201d'
  surface-container-high: '#292a28'
  surface-container-highest: '#333532'
  on-surface: '#e2e3de'
  on-surface-variant: '#c5c5d4'
  inverse-surface: '#e2e3de'
  inverse-on-surface: '#2f312e'
  outline: '#8f909e'
  outline-variant: '#454652'
  surface-tint: '#bac3ff'
  primary: '#bac3ff'
  on-primary: '#092386'
  primary-container: '#4255b5'
  on-primary-container: '#cfd4ff'
  inverse-primary: '#4356b6'
  secondary: '#c9e830'
  on-secondary: '#2b3400'
  secondary-container: '#adcb00'
  on-secondary-container: '#455200'
  tertiary: '#bdc7db'
  on-tertiary: '#273140'
  tertiary-container: '#545e6f'
  on-tertiary-container: '#ced7ec'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dee1ff'
  primary-fixed-dim: '#bac3ff'
  on-primary-fixed: '#001159'
  on-primary-fixed-variant: '#293d9d'
  secondary-fixed: '#d1f039'
  secondary-fixed-dim: '#b5d314'
  on-secondary-fixed: '#181e00'
  on-secondary-fixed-variant: '#404c00'
  tertiary-fixed: '#d9e3f7'
  tertiary-fixed-dim: '#bdc7db'
  on-tertiary-fixed: '#121c2a'
  on-tertiary-fixed-variant: '#3e4757'
  background: '#121411'
  on-background: '#e2e3de'
  surface-variant: '#333532'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 64px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Manrope
    fontSize: 40px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.05em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 80px
  margin-mobile: 20px
  section-gap: 120px
---

## Brand & Style

The design system is built on the narrative of "Engineered Momentum"—a visual language that balances high-end editorial sophistication with technical precision. It is designed for a premium enterprise audience, positioning the product as a catalyst for large-scale digital transformation.

The aesthetic draws from modern technology consulting: it is confident, expansive, and avoids the cluttered clichés of the staffing industry. The style is **Corporate Modern with Editorial Asymmetry**, utilizing generous whitespace, structured layouts, and cinematic photography. Visual weight is managed through deep, saturated backgrounds and sharp, high-contrast typography. 

Key principles:
- **Cinematic Scale:** Use large-scale imagery with dark indigo overlays to create depth and focus.
- **Controlled Tension:** Introduce slight asymmetry in layout grids to suggest movement and progress.
- **Technical Credibility:** Maintain a "blueprint" level of precision in spacing and alignment.
- **Outcome Focused:** Every visual element must drive the eye toward a clear business insight or call to action.

## Colors

The palette is anchored in a dual-thematic approach: **Midnight Navy** for high-impact technical sections and **Warm White** for content-heavy editorial sections.

- **Indigo (#4255B5):** Used for structural accents, primary brand moments, and subtle iconographic backgrounds.
- **Lime (#B5D313):** Reserved strictly for high-priority CTA highlights, active state indicators, and micro-labels. Its high contrast against navy ensures immediate visibility.
- **Midnight Navy (#07111F) & Deep Navy (#0C1A2B):** Form the foundation of the dark mode interface, providing a sophisticated, "command-center" feel.
- **Warm White (#F7F7F2):** Used for long-form reading and white-papers to reduce eye strain and provide an "executive report" aesthetic.
- **Hairline Border (#DDE3EA):** Used for razor-thin separators (1px) to maintain structural integrity without visual noise.

## Typography

This design system uses a high-contrast typographic pairing to signal both authority and efficiency. 

- **Manrope (Bold/ExtraBold):** Used for display and headlines. It brings a modern, geometric, yet friendly personality to the technical discourse. Headlines should use tight tracking (-0.01em to -0.02em) to appear "locked in" and engineered.
- **Inter:** Used for all UI elements, body copy, and data visualizations. It is chosen for its exceptional legibility at small sizes and its neutral, systematic character.

**Editorial Scaling:** On desktop, use `display-lg` for hero statements. Maintain generous line heights for body copy (1.6) to ensure an open, professional reading experience. All labels and overlines should use `label-caps` for a structured, technical feel.

## Layout & Spacing

The layout philosophy follows a **Precision Fluid Grid**. It utilizes a 12-column system for desktop with significant outer margins to focus the user's attention.

- **Asymmetry:** In editorial layouts, push key text blocks to span columns 2-7, while leaving columns 8-12 for secondary data or whitespace.
- **Section Breathing Room:** Use large vertical gaps (`section-gap`: 120px) between major content blocks to convey a sense of scale and importance.
- **Rhythm:** All spacing (padding, margins, internal gaps) must be multiples of the 8px `base` unit to maintain technical consistency.
- **Mobile Reflow:** For mobile, collapse to a single column with 20px side margins. Typography scales down slightly, but maintains its bold weight.

## Elevation & Depth

This design system eschews traditional shadows in favor of **Tonal Layering and Precision Outlines**. Depth is created through value contrast rather than artificial light sources.

- **Flat Elevation:** Most components sit flush on the background. Hierarchy is established by changing the background hex (e.g., a `Deep Navy` card on a `Midnight Navy` background).
- **Hairline Borders:** Use the `Hairline Border` (#DDE3EA) at 1px thickness for defining card boundaries on light backgrounds. On dark backgrounds, use a low-opacity white (10%) for borders.
- **Overlays:** Dark Indigo (#4255B5 at 40-60% opacity) should be used over background images to ensure typography remains legible and high-contrast.
- **Zero Glassmorphism:** Avoid backdrop blurs. All layers should be opaque to maintain a solid, dependable enterprise feel.

## Shapes

The shape language is a strategic mix of **Full Radii and Sharp Intersections**.

- **Pill Shapes:** All primary action buttons, navigation items, and status tags must be fully rounded (pill-shaped). This provides a "friendly" counterpoint to the rigid grid and sharp typography.
- **Containers:** Large sections, cards, and image containers should remain sharp or use minimal rounding (0.5rem) to maintain a professional, architectural feel.
- **Icons:** Use linear, 2px stroke icons with slightly rounded caps to match the `Inter` typeface.

## Components

- **Buttons:** Primary buttons are pill-shaped with `Indigo` backgrounds and white text. The "High-Momentum" CTA uses `Lime` with `Midnight Navy` text for maximum impact.
- **Navigation:** The top-tier navigation uses pill-shaped background highlights on hover. The active state is indicated by a subtle `Lime` dot or a thin stroke.
- **Input Fields:** Underlined or framed with `Hairline Border`. Focus states use a 2px `Indigo` bottom border. Labels use `label-caps`.
- **Cards:** Use a "No-Shadow" approach. Cards on dark backgrounds use `Deep Navy` fill with a subtle 1px border. On light backgrounds, use `White` with `Hairline Border`.
- **Chips/Labels:** Small, pill-shaped indicators. Use `Lime` for "Success" or "Active," and `Slate` for "Neutral" or "Draft" states.
- **Data Viz:** Charts should use a palette of Indigo, Lime, and Slate. Lines should be crisp (2px) and use small circular markers for data points.
- **Lists:** Lists should be separated by `Hairline Border` with generous vertical padding (16px - 24px) to ensure an executive, uncrowded feel.